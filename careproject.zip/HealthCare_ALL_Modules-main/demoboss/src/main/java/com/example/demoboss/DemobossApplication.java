package com.example.demoboss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemobossApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemobossApplication.class, args);
	}

}
